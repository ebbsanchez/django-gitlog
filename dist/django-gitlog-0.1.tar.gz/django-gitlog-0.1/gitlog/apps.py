from django.apps import AppConfig


class GitlogConfig(AppConfig):
    name = 'gitlog'
